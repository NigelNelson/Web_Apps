// Class: SE2840 - Person Tracker
// Name: YOUR NAME HERE
// Class Section: N/A

// TODO add client side functionality

window.onload = () => {

}
