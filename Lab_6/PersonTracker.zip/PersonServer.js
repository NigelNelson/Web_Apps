// Class: SE2840 - Person Tracker
// Name: YOUR NAME HERE
// Class Section: N/A

// Import the express library
const express = require('express');

const personData = require('./PersonData.js');
const webpagedir = `${__dirname}/srv`;

// Create a new express application
const app = express();

// Instruct the app to listen on port 3000
app.listen(3000, () => {
    console.log("Server is running at http://localhost:3000");
});

// Set a static route for root (/) to send index.html
app.get("/", (request, response) => {
    response.sendFile(`${webpagedir}/PersonTracker.html`);
});

// Set a static route for all resources that don't have an explicit route
//   to use the static directory webpagedir
app.use(express.static(webpagedir));

// TODO: Add additional functions to implement the server JSON API
