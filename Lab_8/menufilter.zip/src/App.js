// Class: SE2840 - Menu Filter
// Name: YOUR NAME HERE
// Class Section: N/A

class App extends React.Component {
    constructor(props) {
        super(props);

        // Set state as needed
        this.state = {};
    }

    render() {

        // TODO filter menuItems
        //    Menu items are passed in through props as this.props.menuItems

        // Render the application
        return (
            <div>
            </div>
        );
    }
}
